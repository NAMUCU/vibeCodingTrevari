import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  companyName: text("company_name"),
  email: text("email"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  companyName: true,
  email: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const companies = pgTable("companies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  businessNumber: text("business_number"),
  category: text("category"),
  region: text("region"),
});

export const insertCompanySchema = createInsertSchema(companies).omit({ id: true });
export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type Company = typeof companies.$inferSelect;

export const contracts = pgTable("contracts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").notNull(),
  companyName: text("company_name").notNull(),
  productName: text("product_name").notNull(),
  productCategory: text("product_category").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: integer("unit_price").notNull(),
  totalAmount: integer("total_amount").notNull(),
  contractDate: text("contract_date").notNull(),
  specWatt: integer("spec_watt"),
  specLumen: integer("spec_lumen"),
  efficiency: text("efficiency"),
});

export const insertContractSchema = createInsertSchema(contracts).omit({ id: true });
export type InsertContract = z.infer<typeof insertContractSchema>;
export type Contract = typeof contracts.$inferSelect;

export const productSpecs = pgTable("product_specs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  contractId: varchar("contract_id").notNull(),
  powerConsumption: integer("power_consumption"),
  luminousFlux: integer("luminous_flux"),
  colorTemperature: integer("color_temperature"),
  certifications: text("certifications").array(),
  ipRating: text("ip_rating"),
  lifespan: integer("lifespan"),
});

export const insertProductSpecSchema = createInsertSchema(productSpecs).omit({ id: true });
export type InsertProductSpec = z.infer<typeof insertProductSpecSchema>;
export type ProductSpec = typeof productSpecs.$inferSelect;

export const aiInsights = pgTable("ai_insights", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull(),
  createdAt: text("created_at").notNull(),
  relatedCompanies: text("related_companies").array(),
});

export const insertAiInsightSchema = createInsertSchema(aiInsights).omit({ id: true });
export type InsertAiInsight = z.infer<typeof insertAiInsightSchema>;
export type AiInsight = typeof aiInsights.$inferSelect;

export const priceAlerts = pgTable("price_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyName: text("company_name").notNull(),
  productCategory: text("product_category"),
  thresholdPercent: integer("threshold_percent").notNull().default(5),
  isActive: integer("is_active").notNull().default(1),
  createdAt: text("created_at").notNull(),
});

export const insertPriceAlertSchema = createInsertSchema(priceAlerts).omit({ id: true });
export type InsertPriceAlert = z.infer<typeof insertPriceAlertSchema>;
export type PriceAlert = typeof priceAlerts.$inferSelect;

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  type: text("type").notNull(),
  isRead: integer("is_read").notNull().default(0),
  createdAt: text("created_at").notNull(),
  relatedCompany: text("related_company"),
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true });
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

export interface MarketShareData {
  category: string;
  company: string;
  share: number;
  amount: number;
}

export interface PriceTrendData {
  month: string;
  company: string;
  avgPrice: number;
  spec: string;
}

export interface KpiData {
  totalContractAmount: number;
  averageUnitPrice: number;
  totalContracts: number;
  monthlyGrowth: number;
}
