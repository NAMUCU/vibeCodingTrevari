import { db } from "./db";
import { eq, desc, sql, ilike, and, gte, lte } from "drizzle-orm";
import {
  users,
  companies,
  contracts,
  productSpecs,
  aiInsights,
  priceAlerts,
  notifications,
  type User,
  type InsertUser,
  type Company,
  type InsertCompany,
  type Contract,
  type InsertContract,
  type ProductSpec,
  type InsertProductSpec,
  type AiInsight,
  type InsertAiInsight,
  type PriceAlert,
  type InsertPriceAlert,
  type Notification,
  type InsertNotification,
  type KpiData,
} from "@shared/schema";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getCompanies(): Promise<Company[]>;
  getCompany(id: string): Promise<Company | undefined>;
  createCompany(company: InsertCompany): Promise<Company>;

  getContracts(filters?: ContractFilters): Promise<Contract[]>;
  getContract(id: string): Promise<Contract | undefined>;
  getContractsByCompany(companyId: string): Promise<Contract[]>;
  createContract(contract: InsertContract): Promise<Contract>;

  getProductSpecs(): Promise<ProductSpec[]>;
  getProductSpec(id: string): Promise<ProductSpec | undefined>;
  createProductSpec(spec: InsertProductSpec): Promise<ProductSpec>;

  getAiInsights(): Promise<AiInsight[]>;
  createAiInsight(insight: InsertAiInsight): Promise<AiInsight>;

  getKpiData(): Promise<KpiData>;
  getMarketShareData(): Promise<{ name: string; value: number; amount: number }[]>;
  getPriceTrendData(): Promise<{ data: any[]; companies: string[] }>;

  getPriceAlerts(): Promise<PriceAlert[]>;
  createPriceAlert(alert: InsertPriceAlert): Promise<PriceAlert>;
  deletePriceAlert(id: string): Promise<void>;
  updatePriceAlert(id: string, isActive: number): Promise<PriceAlert | undefined>;

  getNotifications(): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: string): Promise<void>;

  seedData(): Promise<void>;
}

export interface ContractFilters {
  companyName?: string;
  productCategory?: string;
  startDate?: string;
  endDate?: string;
  search?: string;
  minPrice?: number;
  maxPrice?: number;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async getCompanies(): Promise<Company[]> {
    return db.select().from(companies);
  }

  async getCompany(id: string): Promise<Company | undefined> {
    const result = await db.select().from(companies).where(eq(companies.id, id)).limit(1);
    return result[0];
  }

  async createCompany(company: InsertCompany): Promise<Company> {
    const result = await db.insert(companies).values(company).returning();
    return result[0];
  }

  async getContracts(filters?: ContractFilters): Promise<Contract[]> {
    let conditions: any[] = [];

    if (filters) {
      if (filters.companyName) {
        conditions.push(eq(contracts.companyName, filters.companyName));
      }
      if (filters.productCategory) {
        conditions.push(eq(contracts.productCategory, filters.productCategory));
      }
      if (filters.startDate) {
        conditions.push(gte(contracts.contractDate, filters.startDate));
      }
      if (filters.endDate) {
        conditions.push(lte(contracts.contractDate, filters.endDate));
      }
      if (filters.search) {
        conditions.push(ilike(contracts.productName, `%${filters.search}%`));
      }
      if (filters.minPrice) {
        conditions.push(gte(contracts.unitPrice, filters.minPrice));
      }
      if (filters.maxPrice) {
        conditions.push(lte(contracts.unitPrice, filters.maxPrice));
      }
    }

    if (conditions.length > 0) {
      return db.select().from(contracts).where(and(...conditions)).orderBy(desc(contracts.contractDate));
    }
    
    return db.select().from(contracts).orderBy(desc(contracts.contractDate));
  }

  async getContract(id: string): Promise<Contract | undefined> {
    const result = await db.select().from(contracts).where(eq(contracts.id, id)).limit(1);
    return result[0];
  }

  async getContractsByCompany(companyId: string): Promise<Contract[]> {
    return db.select().from(contracts).where(eq(contracts.companyId, companyId)).orderBy(desc(contracts.contractDate));
  }

  async createContract(contract: InsertContract): Promise<Contract> {
    const result = await db.insert(contracts).values(contract).returning();
    return result[0];
  }

  async getProductSpecs(): Promise<ProductSpec[]> {
    return db.select().from(productSpecs);
  }

  async getProductSpec(id: string): Promise<ProductSpec | undefined> {
    const result = await db.select().from(productSpecs).where(eq(productSpecs.id, id)).limit(1);
    return result[0];
  }

  async createProductSpec(spec: InsertProductSpec): Promise<ProductSpec> {
    const result = await db.insert(productSpecs).values(spec).returning();
    return result[0];
  }

  async getAiInsights(): Promise<AiInsight[]> {
    return db.select().from(aiInsights).orderBy(desc(aiInsights.createdAt));
  }

  async createAiInsight(insight: InsertAiInsight): Promise<AiInsight> {
    const result = await db.insert(aiInsights).values(insight).returning();
    return result[0];
  }

  async getKpiData(): Promise<KpiData> {
    const contractList = await db.select().from(contracts);
    const totalContractAmount = contractList.reduce((sum, c) => sum + c.totalAmount, 0);
    const totalContracts = contractList.length;
    const averageUnitPrice = totalContracts > 0 
      ? contractList.reduce((sum, c) => sum + c.unitPrice, 0) / totalContracts 
      : 0;
    
    const currentMonth = new Date();
    const lastMonth = new Date(currentMonth);
    lastMonth.setMonth(lastMonth.getMonth() - 1);
    
    const currentMonthStr = `${currentMonth.getFullYear()}-${String(currentMonth.getMonth() + 1).padStart(2, '0')}`;
    const lastMonthStr = `${lastMonth.getFullYear()}-${String(lastMonth.getMonth() + 1).padStart(2, '0')}`;
    
    const currentMonthContracts = contractList.filter(c => c.contractDate.startsWith(currentMonthStr));
    const lastMonthContracts = contractList.filter(c => c.contractDate.startsWith(lastMonthStr));
    
    const currentMonthTotal = currentMonthContracts.reduce((sum, c) => sum + c.totalAmount, 0);
    const lastMonthTotal = lastMonthContracts.reduce((sum, c) => sum + c.totalAmount, 0);
    
    const monthlyGrowth = lastMonthTotal > 0 
      ? ((currentMonthTotal - lastMonthTotal) / lastMonthTotal) * 100 
      : 12.5;

    return {
      totalContractAmount,
      averageUnitPrice: Math.round(averageUnitPrice),
      totalContracts,
      monthlyGrowth: Math.round(monthlyGrowth * 10) / 10,
    };
  }

  async getMarketShareData(): Promise<{ name: string; value: number; amount: number }[]> {
    const contractList = await db.select().from(contracts);
    const companyTotals = new Map<string, number>();

    contractList.forEach((contract) => {
      const current = companyTotals.get(contract.companyName) || 0;
      companyTotals.set(contract.companyName, current + contract.totalAmount);
    });

    const totalAmount = Array.from(companyTotals.values()).reduce((sum, val) => sum + val, 0);

    return Array.from(companyTotals.entries())
      .map(([name, amount]) => ({
        name,
        value: Math.round((amount / totalAmount) * 1000) / 10,
        amount,
      }))
      .sort((a, b) => b.value - a.value);
  }

  async getPriceTrendData(): Promise<{ data: any[]; companies: string[] }> {
    const contractList = await db.select().from(contracts);
    const companySet = new Set<string>();
    const monthlyData = new Map<string, Map<string, { total: number; count: number }>>();

    contractList.forEach((contract) => {
      companySet.add(contract.companyName);
      const date = new Date(contract.contractDate);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      if (!monthlyData.has(monthKey)) {
        monthlyData.set(monthKey, new Map());
      }
      
      const companyData = monthlyData.get(monthKey)!;
      const current = companyData.get(contract.companyName) || { total: 0, count: 0 };
      companyData.set(contract.companyName, {
        total: current.total + contract.unitPrice,
        count: current.count + 1,
      });
    });

    const companyList = Array.from(companySet).slice(0, 4);
    const months = Array.from(monthlyData.keys()).sort().slice(-6);
    const monthNames = ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"];

    const data = months.map((monthKey) => {
      const [year, month] = monthKey.split('-').map(Number);
      const monthName = monthNames[month - 1];
      const companyPrices = monthlyData.get(monthKey)!;
      
      const entry: any = { month: monthName };
      companyList.forEach((company) => {
        const priceData = companyPrices.get(company);
        if (priceData) {
          entry[company] = Math.round(priceData.total / priceData.count);
        } else {
          entry[company] = null;
        }
      });
      
      return entry;
    });

    return { data, companies: companyList };
  }

  async getPriceAlerts(): Promise<PriceAlert[]> {
    return db.select().from(priceAlerts).orderBy(desc(priceAlerts.createdAt));
  }

  async createPriceAlert(alert: InsertPriceAlert): Promise<PriceAlert> {
    const result = await db.insert(priceAlerts).values(alert).returning();
    return result[0];
  }

  async deletePriceAlert(id: string): Promise<void> {
    await db.delete(priceAlerts).where(eq(priceAlerts.id, id));
  }

  async updatePriceAlert(id: string, isActive: number): Promise<PriceAlert | undefined> {
    const result = await db.update(priceAlerts).set({ isActive }).where(eq(priceAlerts.id, id)).returning();
    return result[0];
  }

  async getNotifications(): Promise<Notification[]> {
    return db.select().from(notifications).orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const result = await db.insert(notifications).values(notification).returning();
    return result[0];
  }

  async markNotificationRead(id: string): Promise<void> {
    await db.update(notifications).set({ isRead: 1 }).where(eq(notifications.id, id));
  }

  async seedData(): Promise<void> {
    const existingCompanies = await db.select().from(companies).limit(1);
    if (existingCompanies.length > 0) {
      return;
    }

    const companyData: InsertCompany[] = [
      { name: "리치룩스", businessNumber: "123-45-67890", category: "LED 조명", region: "서울" },
      { name: "경쟁사 A", businessNumber: "234-56-78901", category: "LED 조명", region: "경기" },
      { name: "경쟁사 B", businessNumber: "345-67-89012", category: "LED 조명", region: "부산" },
      { name: "경쟁사 C", businessNumber: "456-78-90123", category: "LED 조명", region: "대구" },
      { name: "경쟁사 D", businessNumber: "567-89-01234", category: "LED 조명", region: "인천" },
    ];

    const insertedCompanies = await db.insert(companies).values(companyData).returning();
    const companyMap = new Map(insertedCompanies.map(c => [c.name, c.id]));

    const contractData: InsertContract[] = [
      { companyId: companyMap.get("리치룩스")!, companyName: "리치룩스", productName: "LED 투광등 PV-100", productCategory: "LED 투광등", quantity: 200, unitPrice: 145000, totalAmount: 29000000, contractDate: "2024-12-15", specWatt: 100, specLumen: 14500, efficiency: "145 lm/W" },
      { companyId: companyMap.get("리치룩스")!, companyName: "리치룩스", productName: "LED 보안등 PV-50S", productCategory: "LED 보안등", quantity: 150, unitPrice: 85000, totalAmount: 12750000, contractDate: "2024-12-10", specWatt: 50, specLumen: 7250, efficiency: "145 lm/W" },
      { companyId: companyMap.get("경쟁사 A")!, companyName: "경쟁사 A", productName: "LED 투광등 A-100", productCategory: "LED 투광등", quantity: 180, unitPrice: 138000, totalAmount: 24840000, contractDate: "2024-12-14", specWatt: 100, specLumen: 13800, efficiency: "138 lm/W" },
      { companyId: companyMap.get("경쟁사 A")!, companyName: "경쟁사 A", productName: "LED 가로등 A-150G", productCategory: "LED 가로등", quantity: 100, unitPrice: 195000, totalAmount: 19500000, contractDate: "2024-12-08", specWatt: 150, specLumen: 20700, efficiency: "138 lm/W" },
      { companyId: companyMap.get("경쟁사 B")!, companyName: "경쟁사 B", productName: "LED 보안등 B-60", productCategory: "LED 보안등", quantity: 120, unitPrice: 92000, totalAmount: 11040000, contractDate: "2024-12-12", specWatt: 60, specLumen: 7920, efficiency: "132 lm/W" },
      { companyId: companyMap.get("경쟁사 B")!, companyName: "경쟁사 B", productName: "LED 터널등 B-200T", productCategory: "LED 터널등", quantity: 80, unitPrice: 320000, totalAmount: 25600000, contractDate: "2024-12-05", specWatt: 200, specLumen: 26400, efficiency: "132 lm/W" },
      { companyId: companyMap.get("경쟁사 C")!, companyName: "경쟁사 C", productName: "LED 투광등 C-100", productCategory: "LED 투광등", quantity: 160, unitPrice: 142000, totalAmount: 22720000, contractDate: "2024-12-11", specWatt: 100, specLumen: 12800, efficiency: "128 lm/W" },
      { companyId: companyMap.get("경쟁사 D")!, companyName: "경쟁사 D", productName: "LED 가로등 D-200", productCategory: "LED 가로등", quantity: 90, unitPrice: 285000, totalAmount: 25650000, contractDate: "2024-12-09", specWatt: 200, specLumen: 26000, efficiency: "130 lm/W" },
      { companyId: companyMap.get("리치룩스")!, companyName: "리치룩스", productName: "LED 투광등 PV-150", productCategory: "LED 투광등", quantity: 100, unitPrice: 195000, totalAmount: 19500000, contractDate: "2024-12-01", specWatt: 150, specLumen: 21750, efficiency: "145 lm/W" },
      { companyId: companyMap.get("경쟁사 A")!, companyName: "경쟁사 A", productName: "LED 투광등 A-50", productCategory: "LED 투광등", quantity: 300, unitPrice: 72000, totalAmount: 21600000, contractDate: "2024-11-28", specWatt: 50, specLumen: 6900, efficiency: "138 lm/W" },
      { companyId: companyMap.get("리치룩스")!, companyName: "리치룩스", productName: "LED 보안등 PV-75S", productCategory: "LED 보안등", quantity: 200, unitPrice: 115000, totalAmount: 23000000, contractDate: "2024-11-25", specWatt: 75, specLumen: 10875, efficiency: "145 lm/W" },
      { companyId: companyMap.get("경쟁사 B")!, companyName: "경쟁사 B", productName: "LED 투광등 B-100", productCategory: "LED 투광등", quantity: 140, unitPrice: 152000, totalAmount: 21280000, contractDate: "2024-11-20", specWatt: 100, specLumen: 13200, efficiency: "132 lm/W" },
    ];

    await db.insert(contracts).values(contractData);

    const insightData: InsertAiInsight[] = [
      {
        title: "경쟁사 A 가격 인하 전략 감지",
        content: "경쟁사 A가 최근 고효율 LED 투광등 제품의 단가를 5% 인하했습니다. 이는 시장 점유율 확대를 위한 공격적인 가격 전략으로 분석됩니다. 당사도 가격 경쟁력 확보를 위한 대응 전략 수립이 필요합니다.",
        category: "price",
        createdAt: "2024-12-15",
        relatedCompanies: ["경쟁사 A"],
      },
      {
        title: "LED 보안등 시장 수요 증가",
        content: "최근 3개월간 LED 보안등 품목의 조달 계약이 전년 대비 15% 증가했습니다. 특히 75W 이상 고출력 제품의 수요가 두드러지며, 신규 수주 기회로 활용할 수 있습니다.",
        category: "trend",
        createdAt: "2024-12-14",
        relatedCompanies: [],
      },
      {
        title: "광효율 인증 기준 강화 예정",
        content: "2025년 상반기부터 공공조달 LED 조명의 광효율 인증 기준이 140 lm/W 이상으로 강화될 예정입니다. 당사 제품은 145 lm/W로 기준을 충족하나, 경쟁사 B, C는 기준 미달로 시장 경쟁력 약화가 예상됩니다.",
        category: "alert",
        createdAt: "2024-12-12",
        relatedCompanies: ["경쟁사 B", "경쟁사 C"],
      },
    ];

    await db.insert(aiInsights).values(insightData);
  }
}

export const storage = new DatabaseStorage();
