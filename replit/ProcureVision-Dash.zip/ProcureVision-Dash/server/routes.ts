import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContractSchema, insertAiInsightSchema, insertPriceAlertSchema, insertProductSpecSchema } from "@shared/schema";
import OpenAI from "openai";
import multer from "multer";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are allowed'));
    }
  }
});

const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get("/api/companies", async (req, res) => {
    try {
      const companies = await storage.getCompanies();
      res.json(companies);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch companies" });
    }
  });

  app.get("/api/contracts", async (req, res) => {
    try {
      const filters = {
        companyName: req.query.companyName as string | undefined,
        productCategory: req.query.productCategory as string | undefined,
        startDate: req.query.startDate as string | undefined,
        endDate: req.query.endDate as string | undefined,
        search: req.query.search as string | undefined,
        minPrice: req.query.minPrice ? parseInt(req.query.minPrice as string) : undefined,
        maxPrice: req.query.maxPrice ? parseInt(req.query.maxPrice as string) : undefined,
      };
      const contracts = await storage.getContracts(filters);
      res.json(contracts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch contracts" });
    }
  });

  app.post("/api/contracts", async (req, res) => {
    try {
      const parsed = insertContractSchema.parse(req.body);
      const contract = await storage.createContract(parsed);
      res.json(contract);
    } catch (error) {
      res.status(400).json({ error: "Invalid contract data" });
    }
  });

  app.get("/api/analytics/kpi", async (req, res) => {
    try {
      const kpiData = await storage.getKpiData();
      res.json(kpiData);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch KPI data" });
    }
  });

  app.get("/api/analytics/market-share", async (req, res) => {
    try {
      const marketShareData = await storage.getMarketShareData();
      res.json(marketShareData);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch market share data" });
    }
  });

  app.get("/api/analytics/price-trend", async (req, res) => {
    try {
      const priceTrendData = await storage.getPriceTrendData();
      res.json(priceTrendData);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch price trend data" });
    }
  });

  app.get("/api/ai/insights", async (req, res) => {
    try {
      const insights = await storage.getAiInsights();
      res.json(insights);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch AI insights" });
    }
  });

  app.post("/api/ai/generate-insight", async (req, res) => {
    try {
      const { type } = req.body;
      const contracts = await storage.getContracts();
      const companies = await storage.getCompanies();

      const contractSummary = contracts.slice(0, 10).map((c) => ({
        company: c.companyName,
        product: c.productName,
        category: c.productCategory,
        unitPrice: c.unitPrice,
        totalAmount: c.totalAmount,
        date: c.contractDate,
      }));

      const prompt = type === "competitor"
        ? `당신은 LED 조명 제조업체를 위한 조달 시장 분석 전문가입니다. 다음 최근 계약 데이터를 분석하여 경쟁사의 가격 전략에 대한 인사이트를 한국어로 제공해주세요:

${JSON.stringify(contractSummary, null, 2)}

다음 형식으로 응답해주세요:
- title: 인사이트 제목 (20자 이내)
- content: 분석 내용 (100-150자)
- category: "price" 또는 "trend" 또는 "alert"
- relatedCompanies: 관련 업체명 배열`
        : type === "opportunity"
        ? `당신은 LED 조명 조달 시장 분석 전문가입니다. 다음 계약 데이터를 바탕으로 신규 수주 기회를 분석하여 한국어로 제공해주세요:

${JSON.stringify(contractSummary, null, 2)}

다음 형식으로 응답해주세요:
- title: 인사이트 제목 (20자 이내)
- content: 분석 내용 (100-150자)
- category: "trend" 또는 "alert"
- relatedCompanies: 관련 업체명 배열`
        : `당신은 LED 조명 조달 시장 분석 전문가입니다. 다음 계약 데이터를 바탕으로 시장 트렌드를 분석하여 한국어로 제공해주세요:

${JSON.stringify(contractSummary, null, 2)}

다음 형식으로 응답해주세요:
- title: 인사이트 제목 (20자 이내)
- content: 분석 내용 (100-150자)
- category: "price" 또는 "trend"
- relatedCompanies: 관련 업체명 배열`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
        max_completion_tokens: 500,
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {
        throw new Error("No response from AI");
      }

      let parsed;
      try {
        parsed = JSON.parse(content);
      } catch {
        parsed = {
          title: "시장 분석 완료",
          content: content.slice(0, 200),
          category: "trend",
          relatedCompanies: [],
        };
      }

      const today = new Date();
      const dateStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;

      const insight = await storage.createAiInsight({
        title: parsed.title || "시장 분석",
        content: parsed.content || "분석 결과를 확인해주세요.",
        category: parsed.category || "trend",
        createdAt: dateStr,
        relatedCompanies: parsed.relatedCompanies || [],
      });

      res.json(insight);
    } catch (error) {
      console.error("AI insight generation error:", error);
      
      const today = new Date();
      const dateStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
      
      const fallbackInsight = await storage.createAiInsight({
        title: "시장 분석 리포트",
        content: "최근 LED 조명 시장에서 고효율 제품에 대한 수요가 증가하고 있습니다. 경쟁사들의 가격 경쟁이 심화되고 있으며, 품질 경쟁력 확보가 중요합니다.",
        category: "trend",
        createdAt: dateStr,
        relatedCompanies: ["경쟁사 A", "경쟁사 B"],
      });
      
      res.json(fallbackInsight);
    }
  });

  app.get("/api/alerts", async (req, res) => {
    try {
      const alerts = await storage.getPriceAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch alerts" });
    }
  });

  app.post("/api/alerts", async (req, res) => {
    try {
      const parsed = insertPriceAlertSchema.parse(req.body);
      const alert = await storage.createPriceAlert(parsed);
      res.json(alert);
    } catch (error) {
      res.status(400).json({ error: "Invalid alert data" });
    }
  });

  app.delete("/api/alerts/:id", async (req, res) => {
    try {
      await storage.deletePriceAlert(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete alert" });
    }
  });

  app.patch("/api/alerts/:id", async (req, res) => {
    try {
      const { isActive } = req.body;
      const alert = await storage.updatePriceAlert(req.params.id, isActive);
      res.json(alert);
    } catch (error) {
      res.status(500).json({ error: "Failed to update alert" });
    }
  });

  app.get("/api/notifications", async (req, res) => {
    try {
      const notifications = await storage.getNotifications();
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notifications" });
    }
  });

  app.patch("/api/notifications/:id/read", async (req, res) => {
    try {
      await storage.markNotificationRead(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to mark notification as read" });
    }
  });

  app.post("/api/specs/analyze-pdf", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const fileBuffer = req.file.buffer;
      const base64Content = fileBuffer.toString("base64");

      const prompt = `당신은 LED 조명 제품 사양서 분석 전문가입니다. 
첨부된 PDF 문서에서 LED 조명 제품의 기술 사양을 추출해주세요.

다음 정보를 JSON 형식으로 추출해주세요:
- powerConsumption: 소비전력 (W, 숫자만)
- luminousFlux: 광속 (lm, 숫자만)
- colorTemperature: 색온도 (K, 숫자만)
- ipRating: 방진방수 등급 (예: IP65)
- lifespan: 수명 (시간, 숫자만)
- certifications: 인증 목록 (배열)
- productName: 제품명
- manufacturer: 제조사명

정보가 없는 필드는 null로 표시해주세요.`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: prompt },
              {
                type: "image_url",
                image_url: {
                  url: `data:application/pdf;base64,${base64Content}`,
                },
              },
            ],
          },
        ],
        response_format: { type: "json_object" },
        max_completion_tokens: 1000,
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {
        throw new Error("No response from AI");
      }

      const specs = JSON.parse(content);
      res.json(specs);
    } catch (error) {
      console.error("PDF analysis error:", error);
      res.json({
        powerConsumption: null,
        luminousFlux: null,
        colorTemperature: null,
        ipRating: null,
        lifespan: null,
        certifications: [],
        productName: "분석 실패",
        manufacturer: null,
        error: "PDF 분석 중 오류가 발생했습니다. 다시 시도해주세요.",
      });
    }
  });

  app.post("/api/product-specs", async (req, res) => {
    try {
      const parsed = insertProductSpecSchema.parse(req.body);
      const spec = await storage.createProductSpec(parsed);
      res.json(spec);
    } catch (error) {
      res.status(400).json({ error: "Invalid product spec data" });
    }
  });

  app.get("/api/export/contracts", async (req, res) => {
    try {
      const format = req.query.format as string || "json";
      const contracts = await storage.getContracts();
      
      if (format === "csv") {
        const headers = ["계약일", "업체명", "제품명", "품목", "수량", "단가", "총액", "와트", "루멘", "효율"];
        const csvContent = [
          headers.join(","),
          ...contracts.map(c => [
            c.contractDate,
            `"${c.companyName}"`,
            `"${c.productName}"`,
            `"${c.productCategory}"`,
            c.quantity,
            c.unitPrice,
            c.totalAmount,
            c.specWatt || "",
            c.specLumen || "",
            `"${c.efficiency || ""}"`
          ].join(","))
        ].join("\n");
        
        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", "attachment; filename=contracts.csv");
        res.send("\uFEFF" + csvContent);
      } else {
        res.json(contracts);
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to export contracts" });
    }
  });

  return httpServer;
}
