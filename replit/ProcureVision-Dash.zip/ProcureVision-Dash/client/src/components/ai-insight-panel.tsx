import { Brain, Sparkles, TrendingUp, AlertCircle, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { AiInsight } from "@shared/schema";

interface AiInsightPanelProps {
  insights: AiInsight[];
  isLoading?: boolean;
  onGenerate?: () => void;
  isGenerating?: boolean;
}

const getCategoryIcon = (category: string) => {
  switch (category) {
    case "price":
      return <TrendingUp className="h-4 w-4" />;
    case "alert":
      return <AlertCircle className="h-4 w-4" />;
    default:
      return <Sparkles className="h-4 w-4" />;
  }
};

const getCategoryColor = (category: string) => {
  switch (category) {
    case "price":
      return "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800";
    case "alert":
      return "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-800";
    case "trend":
      return "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800";
    default:
      return "bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-800";
  }
};

const getCategoryLabel = (category: string) => {
  switch (category) {
    case "price":
      return "가격 분석";
    case "alert":
      return "주의 사항";
    case "trend":
      return "시장 트렌드";
    default:
      return "인사이트";
  }
};

export function AiInsightPanel({ insights, isLoading, onGenerate, isGenerating }: AiInsightPanelProps) {
  return (
    <Card data-testid="panel-ai-insights">
      <CardHeader className="flex flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 flex items-center justify-center rounded-md bg-primary/10 text-primary">
            <Brain className="h-5 w-5" />
          </div>
          <div>
            <CardTitle className="text-lg font-semibold">AI 인사이트</CardTitle>
            <CardDescription>시장 동향 및 경쟁사 분석</CardDescription>
          </div>
        </div>
        {onGenerate && (
          <Button
            onClick={onGenerate}
            disabled={isGenerating}
            size="sm"
            data-testid="button-generate-insights"
          >
            {isGenerating ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>분석 중...</span>
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                <span>분석 생성</span>
              </>
            )}
          </Button>
        )}
      </CardHeader>
      <CardContent className="space-y-4">
        {isLoading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="p-4 rounded-md border bg-muted/30 animate-pulse">
              <div className="h-4 w-24 bg-muted rounded mb-2" />
              <div className="h-4 w-full bg-muted rounded mb-1" />
              <div className="h-4 w-3/4 bg-muted rounded" />
            </div>
          ))
        ) : insights.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Brain className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>아직 생성된 인사이트가 없습니다</p>
            <p className="text-sm mt-1">분석 생성 버튼을 클릭해주세요</p>
          </div>
        ) : (
          insights.map((insight) => (
            <div
              key={insight.id}
              className="p-4 rounded-md border-l-4 border bg-muted/30"
              style={{ borderLeftColor: "hsl(var(--primary))" }}
              data-testid={`insight-${insight.id}`}
            >
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="outline" className={getCategoryColor(insight.category)}>
                  {getCategoryIcon(insight.category)}
                  <span className="ml-1">{getCategoryLabel(insight.category)}</span>
                </Badge>
                <span className="text-xs text-muted-foreground">
                  {insight.createdAt}
                </span>
              </div>
              <h4 className="font-medium mb-1">{insight.title}</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {insight.content}
              </p>
              {insight.relatedCompanies && insight.relatedCompanies.length > 0 && (
                <div className="flex items-center gap-2 mt-3">
                  <span className="text-xs text-muted-foreground">관련 업체:</span>
                  <div className="flex gap-1 flex-wrap">
                    {insight.relatedCompanies.map((company) => (
                      <Badge key={company} variant="secondary" className="text-xs">
                        {company}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
