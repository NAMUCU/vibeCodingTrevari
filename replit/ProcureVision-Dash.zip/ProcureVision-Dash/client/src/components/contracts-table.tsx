import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Calendar, Download, X } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Skeleton } from "@/components/ui/skeleton";
import type { Contract } from "@shared/schema";
import { format } from "date-fns";
import { ko } from "date-fns/locale";
import { useToast } from "@/hooks/use-toast";

interface ContractsTableProps {
  showExport?: boolean;
}

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat("ko-KR", {
    style: "currency",
    currency: "KRW",
    maximumFractionDigits: 0,
  }).format(value);
};

const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return `${date.getFullYear()}년 ${date.getMonth() + 1}월 ${date.getDate()}일`;
};

export function ContractsTable({ showExport }: ContractsTableProps) {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [companyFilter, setCompanyFilter] = useState<string>("all");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [priceFilter, setPriceFilter] = useState<string>("all");
  const [startDate, setStartDate] = useState<Date | undefined>();
  const [endDate, setEndDate] = useState<Date | undefined>();

  const { data: allContracts = [], isLoading } = useQuery<Contract[]>({
    queryKey: ["/api/contracts"],
  });

  const filteredContracts = useMemo(() => {
    return allContracts.filter((contract) => {
      if (searchQuery && !contract.productName.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      if (companyFilter !== "all" && contract.companyName !== companyFilter) {
        return false;
      }
      if (categoryFilter !== "all" && contract.productCategory !== categoryFilter) {
        return false;
      }
      if (priceFilter === "low" && contract.unitPrice >= 100000) {
        return false;
      }
      if (priceFilter === "mid" && (contract.unitPrice < 100000 || contract.unitPrice >= 500000)) {
        return false;
      }
      if (priceFilter === "high" && contract.unitPrice < 500000) {
        return false;
      }
      if (startDate) {
        const contractDate = new Date(contract.contractDate);
        if (contractDate < startDate) return false;
      }
      if (endDate) {
        const contractDate = new Date(contract.contractDate);
        if (contractDate > endDate) return false;
      }
      return true;
    });
  }, [allContracts, searchQuery, companyFilter, categoryFilter, priceFilter, startDate, endDate]);

  const companies = useMemo(() => [...new Set(allContracts.map((c) => c.companyName))], [allContracts]);
  const categories = useMemo(() => [...new Set(allContracts.map((c) => c.productCategory))], [allContracts]);

  const hasActiveFilters = searchQuery || companyFilter !== "all" || categoryFilter !== "all" || priceFilter !== "all" || startDate || endDate;

  const clearFilters = () => {
    setSearchQuery("");
    setCompanyFilter("all");
    setCategoryFilter("all");
    setPriceFilter("all");
    setStartDate(undefined);
    setEndDate(undefined);
  };

  const handleExport = (exportFormat: "excel" | "pdf") => {
    if (exportFormat === "excel") {
      window.open("/api/export/contracts?format=csv", "_blank");
      toast({
        title: "다운로드 시작",
        description: "계약 데이터를 Excel(CSV) 형식으로 내보내고 있습니다.",
      });
    } else {
      toast({
        title: "PDF 내보내기",
        description: "PDF 내보내기 기능은 준비 중입니다.",
      });
    }
  };

  return (
    <Card data-testid="table-contracts">
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <CardTitle className="text-lg font-semibold">최근 계약 내역</CardTitle>
            <CardDescription>나라장터 조달 계약 데이터</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="w-fit">
              총 {filteredContracts.length}건
            </Badge>
            {showExport && (
              <div className="flex gap-1">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleExport("excel")}
                  data-testid="button-export-excel"
                >
                  <Download className="h-4 w-4 mr-1" />
                  Excel
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleExport("pdf")}
                  data-testid="button-export-pdf"
                >
                  <Download className="h-4 w-4 mr-1" />
                  PDF
                </Button>
              </div>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col gap-3 mb-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="제품명 검색..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                data-testid="input-search-contracts"
              />
            </div>
            <Select value={companyFilter} onValueChange={setCompanyFilter}>
              <SelectTrigger className="w-[140px]" data-testid="select-company-filter">
                <SelectValue placeholder="업체 선택" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">전체 업체</SelectItem>
                {companies.map((company) => (
                  <SelectItem key={company} value={company}>
                    {company}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[140px]" data-testid="select-category-filter">
                <SelectValue placeholder="품목 선택" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">전체 품목</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={priceFilter} onValueChange={setPriceFilter}>
              <SelectTrigger className="w-[140px]" data-testid="select-price-filter">
                <SelectValue placeholder="가격대" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">전체 가격</SelectItem>
                <SelectItem value="low">10만원 미만</SelectItem>
                <SelectItem value="mid">10~50만원</SelectItem>
                <SelectItem value="high">50만원 이상</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" data-testid="button-start-date">
                  <Calendar className="h-4 w-4 mr-2" />
                  {startDate ? format(startDate, "yyyy.MM.dd", { locale: ko }) : "시작일"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={startDate}
                  onSelect={setStartDate}
                  locale={ko}
                />
              </PopoverContent>
            </Popover>
            <span className="text-muted-foreground">~</span>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" data-testid="button-end-date">
                  <Calendar className="h-4 w-4 mr-2" />
                  {endDate ? format(endDate, "yyyy.MM.dd", { locale: ko }) : "종료일"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={endDate}
                  onSelect={setEndDate}
                  locale={ko}
                />
              </PopoverContent>
            </Popover>
            {hasActiveFilters && (
              <Button variant="ghost" size="sm" onClick={clearFilters} data-testid="button-clear-filters">
                <X className="h-4 w-4 mr-1" />
                필터 초기화
              </Button>
            )}
          </div>
        </div>

        <div className="rounded-md border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="font-semibold">계약일</TableHead>
                <TableHead className="font-semibold">업체명</TableHead>
                <TableHead className="font-semibold">제품명</TableHead>
                <TableHead className="font-semibold">품목</TableHead>
                <TableHead className="font-semibold text-right">수량</TableHead>
                <TableHead className="font-semibold text-right">단가</TableHead>
                <TableHead className="font-semibold text-right">총액</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    {Array.from({ length: 7 }).map((_, j) => (
                      <TableCell key={j}>
                        <Skeleton className="h-4 w-full" />
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : filteredContracts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                    검색 결과가 없습니다
                  </TableCell>
                </TableRow>
              ) : (
                filteredContracts.slice(0, 20).map((contract) => (
                  <TableRow key={contract.id} data-testid={`row-contract-${contract.id}`}>
                    <TableCell className="font-mono text-sm">
                      {formatDate(contract.contractDate)}
                    </TableCell>
                    <TableCell className="font-medium">{contract.companyName}</TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span>{contract.productName}</span>
                        {contract.specWatt && contract.specLumen && (
                          <span className="text-xs text-muted-foreground">
                            {contract.specWatt}W / {contract.specLumen}lm
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {contract.productCategory}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {contract.quantity.toLocaleString()}
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {formatCurrency(contract.unitPrice)}
                    </TableCell>
                    <TableCell className="text-right font-mono font-medium">
                      {formatCurrency(contract.totalAmount)}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
