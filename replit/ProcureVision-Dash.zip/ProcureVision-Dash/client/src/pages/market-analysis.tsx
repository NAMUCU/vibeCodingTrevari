import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Filter } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PriceTrendChart } from "@/components/charts/price-trend-chart";
import { MarketShareChart } from "@/components/charts/market-share-chart";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from "recharts";

export default function MarketAnalysis() {
  const [selectedCategory, setSelectedCategory] = useState("LED 투광등");
  const [selectedSpec, setSelectedSpec] = useState("100W");

  const { data: priceTrendData } = useQuery<any>({
    queryKey: ["/api/analytics/price-trend"],
  });

  const { data: marketShareData } = useQuery<any[]>({
    queryKey: ["/api/analytics/market-share"],
  });

  const specPriceData = [
    { spec: "50W", avgPrice: 85000, minPrice: 72000, maxPrice: 98000 },
    { spec: "100W", avgPrice: 145000, minPrice: 125000, maxPrice: 168000 },
    { spec: "150W", avgPrice: 195000, minPrice: 175000, maxPrice: 225000 },
    { spec: "200W", avgPrice: 285000, minPrice: 250000, maxPrice: 320000 },
    { spec: "300W", avgPrice: 420000, minPrice: 380000, maxPrice: 480000 },
  ];

  const efficiencyData = [
    { company: "리치룩스", efficiency: 145, spec: "100W" },
    { company: "경쟁사 A", efficiency: 138, spec: "100W" },
    { company: "경쟁사 B", efficiency: 132, spec: "100W" },
    { company: "경쟁사 C", efficiency: 128, spec: "100W" },
  ];

  return (
    <div className="p-6 lg:p-8 space-y-6 lg:space-y-8 max-w-7xl mx-auto">
      <div>
        <h1 className="text-2xl lg:text-3xl font-semibold tracking-tight" data-testid="text-page-title">
          시장 분석
        </h1>
        <p className="text-muted-foreground mt-1">
          품목별 시장 동향과 가격 분포를 분석합니다
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Filter className="h-5 w-5" />
            분석 조건
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium">품목</label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-[180px]" data-testid="select-category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="LED 투광등">LED 투광등</SelectItem>
                  <SelectItem value="LED 보안등">LED 보안등</SelectItem>
                  <SelectItem value="LED 가로등">LED 가로등</SelectItem>
                  <SelectItem value="LED 터널등">LED 터널등</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium">사양</label>
              <Select value={selectedSpec} onValueChange={setSelectedSpec}>
                <SelectTrigger className="w-[140px]" data-testid="select-spec">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="50W">50W</SelectItem>
                  <SelectItem value="100W">100W</SelectItem>
                  <SelectItem value="150W">150W</SelectItem>
                  <SelectItem value="200W">200W</SelectItem>
                  <SelectItem value="300W">300W</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button data-testid="button-apply-filter">
                필터 적용
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <PriceTrendChart
        data={priceTrendData?.data ?? []}
        companies={priceTrendData?.companies ?? []}
        title={`${selectedCategory} ${selectedSpec} 월별 단가 추이`}
        description="최근 6개월 평균 단가 변화"
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
        <Card data-testid="chart-spec-price">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">사양별 단가 분포</CardTitle>
            <CardDescription>와트(W)별 평균/최저/최고 단가</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={specPriceData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" opacity={0.3} />
                  <XAxis dataKey="spec" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
                  <YAxis
                    tick={{ fontSize: 12 }}
                    tickFormatter={(v) => `${(v / 10000).toFixed(0)}만`}
                    tickLine={false}
                    axisLine={false}
                  />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-popover border border-popover-border rounded-md px-3 py-2 shadow-md">
                            <p className="font-medium text-sm mb-1">{label}</p>
                            {payload.map((entry: any, index: number) => (
                              <p key={index} className="text-sm" style={{ color: entry.color }}>
                                {entry.name === "avgPrice" ? "평균" : entry.name === "minPrice" ? "최저" : "최고"}:{" "}
                                <span className="font-medium">{Number(entry.value).toLocaleString()}원</span>
                              </p>
                            ))}
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend
                    formatter={(value) => (
                      <span className="text-sm">
                        {value === "avgPrice" ? "평균" : value === "minPrice" ? "최저" : "최고"}
                      </span>
                    )}
                  />
                  <Bar dataKey="minPrice" fill="hsl(var(--chart-4))" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="avgPrice" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="maxPrice" fill="hsl(var(--chart-3))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="chart-efficiency">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">광효율 비교</CardTitle>
            <CardDescription>업체별 lm/W 효율 (높을수록 고효율)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={efficiencyData}
                  layout="vertical"
                  margin={{ top: 5, right: 30, left: 80, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" opacity={0.3} />
                  <XAxis
                    type="number"
                    tick={{ fontSize: 12 }}
                    tickLine={false}
                    axisLine={false}
                    domain={[120, 150]}
                  />
                  <YAxis
                    dataKey="company"
                    type="category"
                    tick={{ fontSize: 12 }}
                    tickLine={false}
                    axisLine={false}
                    width={70}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-popover border border-popover-border rounded-md px-3 py-2 shadow-md">
                            <p className="font-medium text-sm">{data.company}</p>
                            <p className="text-sm text-muted-foreground">
                              광효율: <span className="font-medium text-foreground">{data.efficiency} lm/W</span>
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar
                    dataKey="efficiency"
                    fill="hsl(var(--chart-1))"
                    radius={[0, 4, 4, 0]}
                    label={{ position: "right", fontSize: 12, formatter: (v: number) => `${v} lm/W` }}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <MarketShareChart
        data={marketShareData ?? []}
        title={`${selectedCategory} 시장 점유율`}
        description="수주 금액 기준"
      />
    </div>
  );
}
