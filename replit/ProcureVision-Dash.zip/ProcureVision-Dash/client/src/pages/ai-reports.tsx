import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Brain, Sparkles, FileText, Download, RefreshCw, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AiInsightPanel } from "@/components/ai-insight-panel";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { AiInsight } from "@shared/schema";

export default function AiReports() {
  const [reportType, setReportType] = useState("market");
  const { toast } = useToast();

  const { data: insights, isLoading: insightsLoading } = useQuery<AiInsight[]>({
    queryKey: ["/api/ai/insights"],
  });

  const generateMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/ai/generate-insight", {
        type: reportType,
      });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai/insights"] });
      toast({
        title: "분석 완료",
        description: "새로운 AI 인사이트가 생성되었습니다.",
      });
    },
    onError: (error) => {
      toast({
        title: "분석 실패",
        description: "인사이트 생성 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.",
        variant: "destructive",
      });
    },
  });

  const reportTypes = [
    {
      id: "market",
      name: "시장 트렌드 분석",
      description: "전체 LED 조명 조달 시장의 동향과 가격 변화를 분석합니다",
    },
    {
      id: "competitor",
      name: "경쟁사 가격 전략",
      description: "주요 경쟁사의 최근 가격 변동과 전략을 분석합니다",
    },
    {
      id: "opportunity",
      name: "수주 기회 분석",
      description: "신규 수주 기회와 유망 품목을 파악합니다",
    },
  ];

  const selectedReportInfo = reportTypes.find((r) => r.id === reportType);

  return (
    <div className="p-6 lg:p-8 space-y-6 lg:space-y-8 max-w-7xl mx-auto">
      <div>
        <h1 className="text-2xl lg:text-3xl font-semibold tracking-tight" data-testid="text-page-title">
          AI 리포트
        </h1>
        <p className="text-muted-foreground mt-1">
          AI가 분석한 시장 동향과 경쟁사 인사이트를 확인하세요
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1" data-testid="card-report-generator">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 flex items-center justify-center rounded-md bg-primary/10 text-primary">
                <Brain className="h-5 w-5" />
              </div>
              <div>
                <CardTitle className="text-lg font-semibold">리포트 생성</CardTitle>
                <CardDescription>AI 분석 리포트 요청</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium">분석 유형</label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger data-testid="select-report-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {reportTypes.map((type) => (
                    <SelectItem key={type.id} value={type.id}>
                      {type.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedReportInfo && (
              <div className="p-3 rounded-md bg-muted/50 text-sm text-muted-foreground">
                {selectedReportInfo.description}
              </div>
            )}

            <Button
              className="w-full"
              onClick={() => generateMutation.mutate()}
              disabled={generateMutation.isPending}
              data-testid="button-generate-report"
            >
              {generateMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>분석 중...</span>
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  <span>리포트 생성</span>
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2" data-testid="card-recent-reports">
          <CardHeader className="flex flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 flex items-center justify-center rounded-md bg-primary/10 text-primary">
                <FileText className="h-5 w-5" />
              </div>
              <div>
                <CardTitle className="text-lg font-semibold">최근 리포트</CardTitle>
                <CardDescription>AI가 생성한 분석 리포트</CardDescription>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/ai/insights"] })}
              data-testid="button-refresh-reports"
            >
              <RefreshCw className="h-4 w-4" />
              <span>새로고침</span>
            </Button>
          </CardHeader>
          <CardContent>
            {insightsLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="p-4 rounded-md border bg-muted/30 animate-pulse">
                    <div className="h-4 w-24 bg-muted rounded mb-2" />
                    <div className="h-4 w-full bg-muted rounded mb-1" />
                    <div className="h-4 w-3/4 bg-muted rounded" />
                  </div>
                ))}
              </div>
            ) : insights && insights.length > 0 ? (
              <div className="space-y-3">
                {insights.slice(0, 5).map((insight) => (
                  <div
                    key={insight.id}
                    className="p-4 rounded-md border hover-elevate active-elevate-2 cursor-pointer"
                    data-testid={`report-${insight.id}`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <Badge variant="outline" className="text-xs">
                        {insight.category === "price"
                          ? "가격 분석"
                          : insight.category === "trend"
                          ? "시장 트렌드"
                          : insight.category === "alert"
                          ? "주의 사항"
                          : "인사이트"}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{insight.createdAt}</span>
                    </div>
                    <h4 className="font-medium mb-1">{insight.title}</h4>
                    <p className="text-sm text-muted-foreground line-clamp-2">{insight.content}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <Brain className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p className="font-medium">아직 생성된 리포트가 없습니다</p>
                <p className="text-sm mt-1">좌측에서 분석 유형을 선택하고 리포트를 생성해보세요</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <AiInsightPanel
        insights={insights ?? []}
        isLoading={insightsLoading}
        onGenerate={() => generateMutation.mutate()}
        isGenerating={generateMutation.isPending}
      />
    </div>
  );
}
