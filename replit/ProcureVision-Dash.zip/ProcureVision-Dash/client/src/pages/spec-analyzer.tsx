import { useState, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import { Upload, FileText, Check, AlertCircle, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

interface SpecResult {
  powerConsumption: number | null;
  luminousFlux: number | null;
  colorTemperature: number | null;
  ipRating: string | null;
  lifespan: number | null;
  certifications: string[];
  productName: string;
  manufacturer: string | null;
  error?: string;
}

export default function SpecAnalyzerPage() {
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<SpecResult | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const analyzeMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch("/api/specs/analyze-pdf", {
        method: "POST",
        body: formData,
      });

      if (!res.ok) throw new Error("Analysis failed");
      return res.json();
    },
    onSuccess: (data) => {
      setResult(data);
      if (data.error) {
        toast({
          title: "분석 오류",
          description: data.error,
          variant: "destructive",
        });
      } else {
        toast({
          title: "분석 완료",
          description: "제품 사양이 성공적으로 추출되었습니다.",
        });
      }
    },
    onError: () => {
      toast({
        title: "오류",
        description: "PDF 분석 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && droppedFile.type === "application/pdf") {
      setFile(droppedFile);
      setResult(null);
    } else {
      toast({
        title: "파일 형식 오류",
        description: "PDF 파일만 업로드 가능합니다.",
        variant: "destructive",
      });
    }
  }, [toast]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setResult(null);
    }
  };

  const handleAnalyze = () => {
    if (file) {
      analyzeMutation.mutate(file);
    }
  };

  return (
    <div className="p-6 lg:p-8 space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl lg:text-3xl font-semibold tracking-tight" data-testid="text-page-title">
          규격서 분석
        </h1>
        <p className="text-muted-foreground mt-1">
          PDF 규격서를 업로드하면 AI가 제품 사양을 자동으로 추출합니다
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Upload className="h-5 w-5" />
            PDF 업로드
          </CardTitle>
          <CardDescription>
            LED 조명 제품 규격서를 업로드해주세요 (최대 10MB)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              isDragging ? "border-primary bg-primary/5" : "border-muted-foreground/25"
            }`}
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
          >
            {file ? (
              <div className="flex flex-col items-center gap-4">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <FileText className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <p className="font-medium">{file.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {(file.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setFile(null);
                      setResult(null);
                    }}
                    data-testid="button-clear-file"
                  >
                    파일 변경
                  </Button>
                  <Button
                    onClick={handleAnalyze}
                    disabled={analyzeMutation.isPending}
                    data-testid="button-analyze"
                  >
                    {analyzeMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        분석 중...
                      </>
                    ) : (
                      "분석 시작"
                    )}
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-4">
                <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center">
                  <Upload className="h-8 w-8 text-muted-foreground" />
                </div>
                <div>
                  <p className="font-medium">파일을 여기에 끌어다 놓거나</p>
                  <p className="text-sm text-muted-foreground">클릭하여 업로드하세요</p>
                </div>
                <label>
                  <input
                    type="file"
                    accept=".pdf"
                    className="hidden"
                    onChange={handleFileChange}
                    data-testid="input-file"
                  />
                  <Button variant="outline" asChild>
                    <span>파일 선택</span>
                  </Button>
                </label>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {result && (
        <Card data-testid="card-analysis-result">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              {result.error ? (
                <AlertCircle className="h-5 w-5 text-destructive" />
              ) : (
                <Check className="h-5 w-5 text-green-500" />
              )}
              분석 결과
            </CardTitle>
          </CardHeader>
          <CardContent>
            {result.error ? (
              <p className="text-muted-foreground">{result.error}</p>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-muted-foreground">제품명</p>
                    <p className="font-medium">{result.productName || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">제조사</p>
                    <p className="font-medium">{result.manufacturer || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">소비전력</p>
                    <p className="font-medium">
                      {result.powerConsumption ? `${result.powerConsumption}W` : "-"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">광속</p>
                    <p className="font-medium">
                      {result.luminousFlux ? `${result.luminousFlux}lm` : "-"}
                    </p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-muted-foreground">색온도</p>
                    <p className="font-medium">
                      {result.colorTemperature ? `${result.colorTemperature}K` : "-"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">방진방수 등급</p>
                    <p className="font-medium">{result.ipRating || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">수명</p>
                    <p className="font-medium">
                      {result.lifespan ? `${result.lifespan.toLocaleString()}시간` : "-"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">인증</p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {result.certifications && result.certifications.length > 0 ? (
                        result.certifications.map((cert, i) => (
                          <Badge key={i} variant="secondary" className="text-xs">
                            {cert}
                          </Badge>
                        ))
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
