import { useQuery } from "@tanstack/react-query";
import { DollarSign, Package, TrendingUp, FileText } from "lucide-react";
import { KpiCard } from "@/components/kpi-card";
import { MarketShareChart } from "@/components/charts/market-share-chart";
import { PriceTrendChart } from "@/components/charts/price-trend-chart";
import { ContractsTable } from "@/components/contracts-table";
import type { KpiData } from "@shared/schema";

const formatCurrency = (value: number) => {
  if (value >= 100000000) {
    return `${(value / 100000000).toFixed(1)}억원`;
  } else if (value >= 10000000) {
    return `${(value / 10000000).toFixed(1)}천만원`;
  }
  return `${(value / 10000).toFixed(0)}만원`;
};

export default function Dashboard() {
  const { data: kpiData, isLoading: kpiLoading } = useQuery<KpiData>({
    queryKey: ["/api/analytics/kpi"],
  });

  const { data: marketShareData } = useQuery<any[]>({
    queryKey: ["/api/analytics/market-share"],
  });

  const { data: priceTrendData } = useQuery<any>({
    queryKey: ["/api/analytics/price-trend"],
  });

  return (
    <div className="p-6 lg:p-8 space-y-6 lg:space-y-8 max-w-7xl mx-auto">
      <div>
        <h1 className="text-2xl lg:text-3xl font-semibold tracking-tight" data-testid="text-page-title">
          대시보드
        </h1>
        <p className="text-muted-foreground mt-1">
          LED 조명 조달 시장 현황을 한눈에 파악하세요
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
        <KpiCard
          title="당월 수주 총액"
          value={kpiLoading ? "..." : formatCurrency(kpiData?.totalContractAmount ?? 0)}
          change={kpiData?.monthlyGrowth}
          changeLabel="전월 대비"
          icon={<DollarSign className="h-5 w-5" />}
          testId="kpi-total-amount"
        />
        <KpiCard
          title="평균 단가"
          value={kpiLoading ? "..." : `${((kpiData?.averageUnitPrice ?? 0) / 10000).toFixed(1)}만원`}
          change={-2.3}
          changeLabel="전월 대비"
          icon={<TrendingUp className="h-5 w-5" />}
          testId="kpi-avg-price"
        />
        <KpiCard
          title="총 계약 건수"
          value={kpiLoading ? "..." : `${kpiData?.totalContracts ?? 0}건`}
          change={8.5}
          changeLabel="전월 대비"
          icon={<FileText className="h-5 w-5" />}
          testId="kpi-total-contracts"
        />
        <KpiCard
          title="등록 품목"
          value="127개"
          change={3.2}
          changeLabel="전월 대비"
          icon={<Package className="h-5 w-5" />}
          testId="kpi-products"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
        <MarketShareChart
          data={marketShareData ?? []}
          title="업체별 시장 점유율"
          description="LED 조명 품목 기준"
        />
        <PriceTrendChart
          data={priceTrendData?.data ?? []}
          companies={priceTrendData?.companies ?? []}
          title="월별 단가 추이"
          description="LED 투광등 100W 기준"
        />
      </div>

      <ContractsTable showExport />
    </div>
  );
}
