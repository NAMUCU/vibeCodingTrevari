import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Users, TrendingDown, TrendingUp, Minus, Building2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PriceTrendChart } from "@/components/charts/price-trend-chart";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";

interface CompetitorData {
  id: string;
  name: string;
  marketShare: number;
  avgPrice: number;
  priceChange: number;
  mainProducts: string[];
  contracts: number;
}

export default function Competitors() {
  const [selectedCompany1, setSelectedCompany1] = useState("리치룩스");
  const [selectedCompany2, setSelectedCompany2] = useState("경쟁사 A");

  const { data: priceTrendData } = useQuery<any>({
    queryKey: ["/api/analytics/price-trend"],
  });

  const competitors: CompetitorData[] = [
    {
      id: "1",
      name: "리치룩스",
      marketShare: 28.5,
      avgPrice: 145000,
      priceChange: -2.3,
      mainProducts: ["LED 투광등", "LED 보안등"],
      contracts: 47,
    },
    {
      id: "2",
      name: "경쟁사 A",
      marketShare: 22.3,
      avgPrice: 138000,
      priceChange: -5.2,
      mainProducts: ["LED 투광등", "LED 가로등"],
      contracts: 38,
    },
    {
      id: "3",
      name: "경쟁사 B",
      marketShare: 18.7,
      avgPrice: 152000,
      priceChange: 1.5,
      mainProducts: ["LED 보안등", "LED 터널등"],
      contracts: 31,
    },
    {
      id: "4",
      name: "경쟁사 C",
      marketShare: 15.2,
      avgPrice: 142000,
      priceChange: -1.8,
      mainProducts: ["LED 투광등"],
      contracts: 25,
    },
    {
      id: "5",
      name: "경쟁사 D",
      marketShare: 8.4,
      avgPrice: 158000,
      priceChange: 3.2,
      mainProducts: ["LED 가로등", "LED 터널등"],
      contracts: 14,
    },
  ];

  const specComparisonData = [
    { spec: "소비전력", company1: "100W", company2: "100W", unit: "W" },
    { spec: "광효율", company1: "145 lm/W", company2: "138 lm/W", unit: "lm/W", highlight: true },
    { spec: "광속", company1: "14,500 lm", company2: "13,800 lm", unit: "lm" },
    { spec: "색온도", company1: "5,000K", company2: "5,000K", unit: "K" },
    { spec: "수명", company1: "50,000시간", company2: "45,000시간", unit: "시간" },
    { spec: "방수등급", company1: "IP66", company2: "IP65", unit: "" },
    { spec: "평균 단가", company1: "145,000원", company2: "138,000원", unit: "원" },
  ];

  const company1 = competitors.find((c) => c.name === selectedCompany1);
  const company2 = competitors.find((c) => c.name === selectedCompany2);

  return (
    <div className="p-6 lg:p-8 space-y-6 lg:space-y-8 max-w-7xl mx-auto">
      <div>
        <h1 className="text-2xl lg:text-3xl font-semibold tracking-tight" data-testid="text-page-title">
          경쟁사 비교
        </h1>
        <p className="text-muted-foreground mt-1">
          주요 경쟁사의 가격 전략과 제품 사양을 비교 분석합니다
        </p>
      </div>

      <Card data-testid="table-competitors-overview">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 flex items-center justify-center rounded-md bg-primary/10 text-primary">
              <Users className="h-5 w-5" />
            </div>
            <div>
              <CardTitle className="text-lg font-semibold">경쟁사 현황</CardTitle>
              <CardDescription>LED 조명 조달 시장 주요 업체</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="font-semibold">업체명</TableHead>
                  <TableHead className="font-semibold text-right">시장 점유율</TableHead>
                  <TableHead className="font-semibold text-right">평균 단가</TableHead>
                  <TableHead className="font-semibold text-right">단가 변동</TableHead>
                  <TableHead className="font-semibold">주요 품목</TableHead>
                  <TableHead className="font-semibold text-right">계약 건수</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {competitors.map((competitor) => (
                  <TableRow key={competitor.id} data-testid={`row-competitor-${competitor.id}`}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-muted-foreground" />
                        {competitor.name}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full"
                            style={{ width: `${competitor.marketShare}%` }}
                          />
                        </div>
                        <span className="font-mono text-sm">{competitor.marketShare}%</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      {competitor.avgPrice.toLocaleString()}원
                    </TableCell>
                    <TableCell className="text-right">
                      <div
                        className={cn(
                          "flex items-center justify-end gap-1 font-medium",
                          competitor.priceChange > 0 && "text-emerald-600 dark:text-emerald-500",
                          competitor.priceChange < 0 && "text-red-600 dark:text-red-500",
                          competitor.priceChange === 0 && "text-muted-foreground"
                        )}
                      >
                        {competitor.priceChange > 0 && <TrendingUp className="h-4 w-4" />}
                        {competitor.priceChange < 0 && <TrendingDown className="h-4 w-4" />}
                        {competitor.priceChange === 0 && <Minus className="h-4 w-4" />}
                        <span>
                          {competitor.priceChange > 0 && "+"}
                          {competitor.priceChange}%
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1 flex-wrap">
                        {competitor.mainProducts.map((product) => (
                          <Badge key={product} variant="outline" className="text-xs">
                            {product}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-mono">{competitor.contracts}건</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <PriceTrendChart
        data={priceTrendData?.data ?? []}
        companies={priceTrendData?.companies ?? []}
        title="경쟁사별 단가 추이 비교"
        description="LED 투광등 100W 기준 월별 평균 단가"
      />

      <Card data-testid="comparison-detail">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">상세 비교</CardTitle>
          <CardDescription>두 업체 간 제품 사양 및 가격 비교</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium">업체 1</label>
              <Select value={selectedCompany1} onValueChange={setSelectedCompany1}>
                <SelectTrigger className="w-[160px]" data-testid="select-company1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {competitors.map((c) => (
                    <SelectItem key={c.id} value={c.name}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium">업체 2</label>
              <Select value={selectedCompany2} onValueChange={setSelectedCompany2}>
                <SelectTrigger className="w-[160px]" data-testid="select-company2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {competitors.map((c) => (
                    <SelectItem key={c.id} value={c.name}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="font-semibold">사양</TableHead>
                  <TableHead className="font-semibold text-center">{selectedCompany1}</TableHead>
                  <TableHead className="font-semibold text-center">{selectedCompany2}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {specComparisonData.map((row) => (
                  <TableRow
                    key={row.spec}
                    className={cn(row.highlight && "bg-primary/5")}
                  >
                    <TableCell className="font-medium">{row.spec}</TableCell>
                    <TableCell className="text-center font-mono">{row.company1}</TableCell>
                    <TableCell className="text-center font-mono">{row.company2}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
