import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Bell, Plus, Trash2, ToggleLeft, ToggleRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { PriceAlert, Company } from "@shared/schema";

export default function AlertsPage() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [threshold, setThreshold] = useState("5");

  const { data: alerts = [], isLoading } = useQuery<PriceAlert[]>({
    queryKey: ["/api/alerts"],
  });

  const { data: companies = [] } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
  });

  const createAlertMutation = useMutation({
    mutationFn: async (data: { companyName: string; productCategory?: string; thresholdPercent: number; createdAt: string }) => {
      return apiRequest("POST", "/api/alerts", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      setIsDialogOpen(false);
      setSelectedCompany("");
      setSelectedCategory("");
      setThreshold("5");
      toast({
        title: "알림 설정 완료",
        description: "가격 변동 알림이 등록되었습니다.",
      });
    },
  });

  const deleteAlertMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/alerts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      toast({
        title: "알림 삭제",
        description: "알림 설정이 삭제되었습니다.",
      });
    },
  });

  const toggleAlertMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: number }) => {
      return apiRequest("PATCH", `/api/alerts/${id}`, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
    },
  });

  const handleCreateAlert = () => {
    if (!selectedCompany) {
      toast({
        title: "오류",
        description: "업체를 선택해주세요.",
        variant: "destructive",
      });
      return;
    }

    const today = new Date();
    const dateStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;

    createAlertMutation.mutate({
      companyName: selectedCompany,
      productCategory: selectedCategory || undefined,
      thresholdPercent: parseInt(threshold),
      createdAt: dateStr,
    });
  };

  return (
    <div className="p-6 lg:p-8 space-y-6 max-w-4xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-semibold tracking-tight" data-testid="text-page-title">
            알림 설정
          </h1>
          <p className="text-muted-foreground mt-1">
            경쟁사 가격 변동 알림을 설정하세요
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-alert">
              <Plus className="h-4 w-4 mr-2" />
              알림 추가
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>가격 변동 알림 설정</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>모니터링 업체</Label>
                <Select value={selectedCompany} onValueChange={setSelectedCompany}>
                  <SelectTrigger data-testid="select-alert-company">
                    <SelectValue placeholder="업체 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    {companies.map((company) => (
                      <SelectItem key={company.id} value={company.name}>
                        {company.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>품목 (선택사항)</Label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger data-testid="select-alert-category">
                    <SelectValue placeholder="전체 품목" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">전체 품목</SelectItem>
                    <SelectItem value="LED 투광등">LED 투광등</SelectItem>
                    <SelectItem value="LED 보안등">LED 보안등</SelectItem>
                    <SelectItem value="LED 가로등">LED 가로등</SelectItem>
                    <SelectItem value="LED 터널등">LED 터널등</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>가격 변동 임계값 (%)</Label>
                <Input
                  type="number"
                  value={threshold}
                  onChange={(e) => setThreshold(e.target.value)}
                  min="1"
                  max="50"
                  data-testid="input-threshold"
                />
                <p className="text-xs text-muted-foreground">
                  단가가 설정한 비율 이상 변동 시 알림을 받습니다
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                취소
              </Button>
              <Button
                onClick={handleCreateAlert}
                disabled={createAlertMutation.isPending}
                data-testid="button-confirm-alert"
              >
                {createAlertMutation.isPending ? "저장 중..." : "알림 등록"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Bell className="h-5 w-5" />
            등록된 알림
          </CardTitle>
          <CardDescription>
            가격 변동 발생 시 대시보드에서 알림을 받습니다
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : alerts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              등록된 알림이 없습니다
            </div>
          ) : (
            <div className="space-y-3">
              {alerts.map((alert) => (
                <div
                  key={alert.id}
                  className="flex items-center justify-between p-4 rounded-md border"
                  data-testid={`alert-${alert.id}`}
                >
                  <div className="flex items-center gap-4">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() =>
                        toggleAlertMutation.mutate({
                          id: alert.id,
                          isActive: alert.isActive === 1 ? 0 : 1,
                        })
                      }
                      data-testid={`button-toggle-${alert.id}`}
                    >
                      {alert.isActive === 1 ? (
                        <ToggleRight className="h-6 w-6 text-primary" />
                      ) : (
                        <ToggleLeft className="h-6 w-6 text-muted-foreground" />
                      )}
                    </Button>
                    <div>
                      <p className="font-medium">{alert.companyName}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-xs">
                          {alert.productCategory || "전체 품목"}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          {alert.thresholdPercent}% 이상 변동 시
                        </span>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteAlertMutation.mutate(alert.id)}
                    data-testid={`button-delete-${alert.id}`}
                  >
                    <Trash2 className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
