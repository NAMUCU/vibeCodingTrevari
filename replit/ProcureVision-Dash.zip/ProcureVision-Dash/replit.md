# ProcureVision

## Overview

ProcureVision is a B2B procurement analytics dashboard designed for Korean manufacturing enterprises. It provides strategic insights into public procurement markets by combining product specifications with pricing data for LED lighting products. The application features market analysis, competitor comparison, and AI-powered reporting capabilities with full Korean language support.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing (lightweight alternative to React Router)
- **State Management**: TanStack React Query for server state management and caching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming (light/dark mode support)
- **Charts**: Recharts for data visualization (pie charts, line charts, bar charts)

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints under `/api/*` prefix
- **Build Tool**: esbuild for server bundling, Vite for client bundling

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` contains all database table definitions
- **Validation**: Zod schemas generated from Drizzle schemas using drizzle-zod
- **Current Storage**: In-memory storage implementation (`MemStorage` class) with interface for database migration

### Key Design Patterns
- **Shared Types**: The `shared/` directory contains schema definitions used by both client and server
- **Path Aliases**: `@/` maps to client source, `@shared/` maps to shared directory
- **Component Structure**: Reusable UI components in `components/ui/`, feature components in `components/`
- **Page-based Routing**: Each route has a corresponding page component in `pages/`

### Theme System
- CSS variables define color tokens in `index.css`
- ThemeProvider context manages light/dark mode state
- Design follows Material Design principles optimized for Korean B2B enterprise users

## External Dependencies

### AI Integration
- **OpenAI API**: Used for generating market insights and AI reports
- **Configuration**: Uses environment variables `AI_INTEGRATIONS_OPENAI_BASE_URL` and `AI_INTEGRATIONS_OPENAI_API_KEY`

### Database
- **PostgreSQL**: Primary database (configured via `DATABASE_URL` environment variable)
- **Drizzle Kit**: Database migration tool (`npm run db:push` for schema sync)

### Third-Party Services
- **Google Fonts**: Noto Sans KR for Korean typography, JetBrains Mono for data display

### Key NPM Dependencies
- Express.js ecosystem: express, express-session, connect-pg-simple
- UI primitives: Full Radix UI component suite
- Data handling: date-fns, zod, drizzle-orm
- Charting: recharts, embla-carousel-react