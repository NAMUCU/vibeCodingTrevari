# ProcureVision Design Guidelines

## Design Approach

**Selected Framework**: Material Design principles via shadcn/ui component system
**Justification**: B2B data-intensive dashboard requiring clarity, efficiency, and professional credibility. Korean enterprise users expect clean, organized interfaces with strong information hierarchy.

## Typography System

### Font Family
- **Primary**: Pretendard (Korean-optimized) or Noto Sans KR via Google Fonts CDN
- **Monospace**: JetBrains Mono for data/numbers in tables

### Hierarchy
- **Page Titles**: text-2xl/text-3xl, font-semibold (대시보드, 시장 분석)
- **Section Headers**: text-xl, font-semibold
- **Card Titles**: text-lg, font-medium
- **Body Text**: text-base, font-normal
- **Data Labels**: text-sm, font-medium
- **Table Content**: text-sm, font-normal
- **KPI Numbers**: text-4xl, font-bold (수주 총액 등)
- **Metadata**: text-xs, text-muted-foreground

## Layout System

### Spacing Primitives
**Standard Units**: Tailwind spacing of 2, 4, 6, 8, 12, 16 (p-4, gap-6, mt-8, mb-12)
- Component padding: p-6
- Card spacing: gap-4 internally, gap-6 between cards
- Section margins: mb-8 to mb-12
- Page padding: p-8

### Grid Structure
- **Sidebar**: Fixed w-64, full height
- **Main Content**: Remaining width with max-w-7xl container, px-8 padding
- **Dashboard Cards**: grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6
- **Chart Sections**: grid grid-cols-1 lg:grid-cols-2 gap-8

## Component Library

### Navigation
**Sidebar** (left, fixed):
- Logo/brand at top (h-16)
- Menu items: p-3, rounded-lg, gap-3 for icon+text
- Active state: distinctive background treatment
- Sections: 대시보드, 시장 분석, 경쟁사 비교, AI 리포트

**Top Bar**:
- Height: h-16, border-b
- Search bar: max-w-md with icon
- User profile: right-aligned avatar + dropdown

### Data Display

**KPI Cards**:
- Card component from shadcn/ui
- Structure: Icon + Label (text-sm muted) + Large Number (text-4xl) + Trend indicator
- Padding: p-6
- Layout: Grid of 4 cards on desktop

**Charts** (Recharts):
- Container height: h-80 to h-96
- Responsive: Full width with aspect ratio preservation
- Legend: bottom placement
- Tooltips: Korean labels with proper number formatting

**Data Table** (shadcn/ui):
- Sticky header
- Row height: py-4
- Alternating row treatment for readability
- Sortable columns with Korean labels
- Filters: Top toolbar with select dropdowns and search input

### Forms & Inputs
**Search Bar**:
- Input with search icon prefix
- Placeholder: "업체명, 품목 검색..."
- Height: h-10

**Filter Controls**:
- shadcn/ui Select components
- Labels above inputs (text-sm font-medium)
- Grouped in horizontal layout with gap-4

### Interactive Elements

**Buttons**:
- Primary CTA: default shadcn/ui button variant
- Secondary: outline variant
- Icon buttons: ghost variant
- Sizes: h-10 for standard, h-9 for compact

**Cards**:
- shadcn/ui Card with CardHeader, CardTitle, CardContent
- Subtle border, no heavy shadows
- Hover state for interactive cards

**AI Insight Panel**:
- Distinct visual treatment (border-l-4 accent)
- Icon + generated text content
- Background: subtle muted treatment
- Padding: p-6

## Page Layouts

### Dashboard (랜딩)
1. Top: 4-column KPI cards grid
2. Middle: 2-column chart section (market share pie + time series line)
3. Bottom: Recent contracts table

### Market Analysis (시장 분석)
1. Filter toolbar
2. Primary chart: full-width time series
3. Secondary: 2-column comparison charts
4. Supporting data table

### Competitor Comparison (경쟁사 비교)
1. Company selector filters
2. Side-by-side comparison cards
3. Price trend line chart (multi-line)
4. Spec comparison table

### AI Reports (AI 리포트)
1. Report generation trigger
2. Insight cards with distinctive left border accent
3. Supporting data visualization
4. Export options

## Korean Localization

- All labels, buttons, placeholders in Korean
- Number formatting: 123,456,789원
- Date format: YYYY년 MM월 DD일
- Proper spacing for Korean typography (letter-spacing-tight for Korean text)

## Accessibility
- Semantic HTML with proper heading hierarchy
- Form labels associated with inputs
- ARIA labels for icon-only buttons (Korean descriptions)
- Keyboard navigation for all interactive elements
- Sufficient contrast ratios for data readability

## Images
No hero images for this B2B dashboard application. Use icons from Heroicons throughout the interface (chart icons, user icons, search icons, etc.)